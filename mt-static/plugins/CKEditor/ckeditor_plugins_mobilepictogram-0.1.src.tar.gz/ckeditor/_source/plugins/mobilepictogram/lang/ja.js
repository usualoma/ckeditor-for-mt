﻿CKEDITOR.lang.ja.mobilepictogram = {
	title: '絵文字挿入'
};
