﻿CKEDITOR.plugins.setLang('mobilepictogram', 'en', {
	mobilepictogram: {
		toolbar	: 'Emoticon',
		title : 'Insert a Emoticon'
	}
});
