﻿CKEDITOR.plugins.setLang('mobilepictogram', 'ja', {
	mobilepictogram: {
		toolbar	: '絵文字',
		title : '絵文字挿入'
	}
});
