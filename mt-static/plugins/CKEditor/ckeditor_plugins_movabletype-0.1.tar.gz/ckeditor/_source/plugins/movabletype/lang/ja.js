CKEDITOR.plugins.setLang('movabletype', 'ja', {
	movabletype: {
		insert_image: '画像の挿入',
		insert_file: 'ファイルの挿入'
	}
});
