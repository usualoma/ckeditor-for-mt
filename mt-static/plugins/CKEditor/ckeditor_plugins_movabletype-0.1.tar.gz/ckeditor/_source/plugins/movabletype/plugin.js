﻿(function() {

function escapeID(str) {
	return str.replace('customfield', '___ckeditorfield___');
}

CKEDITOR.plugins.add('movabletype', {

init : function(editor) {
	var blog_id = (function() {
		var input = document.getElementById('blog-id');
		if (input) {
			return input.value;
		}
		else {
			return 0;
		}
	})();

	jQuery('head').append(
		'<link rel="stylesheet" href="' + CKEDITOR.basePath + 'plugins/movabletype/css/movabletype.css" type="text/css" />'
	);

	editor.addCommand('mt_insert_image', {
		exec: function() {
			var id = escapeID(editor.element['$'].id);

			jQuery.fn.mtDialog.open(
				ScriptURI + '?__mode=list_assets&amp;_type=asset&amp;edit_field=' + id + '&amp;blog_id=' + blog_id + '&amp;dialog_view=1&amp;filter=class&amp;filter_val=image'
			);
		}
	});

	editor.addCommand('mt_insert_file', {
		exec: function() {
			var id = escapeID(editor.element['$'].id);

			jQuery.fn.mtDialog.open(
				ScriptURI + '?__mode=list_assets&amp;_type=asset&amp;edit_field=' + id + '&amp;blog_id=' + blog_id + '&amp;dialog_view=1'
			);
		}
	});

	if (! editor.lang['movabletype']) {
		editor.lang['movabletype'] = {
			'insert_image': 'Insert image',
			'insert_file': 'Insert File'
		};
	}

	editor.ui.addButton('mt_insert_image', {
		label : editor.lang.movabletype.insert_image,
		command : 'mt_insert_image'
	});
	editor.ui.addButton('mt_insert_file', {
		label : editor.lang.movabletype.insert_file,
		command : 'mt_insert_file'
	});
}

});

})();
