CKEDITOR.plugins.setLang('movabletype', 'en', {
	movabletype: {
		insert_image: 'Insert Image',
		insert_file: 'Insert File'
	}
});
